import { useApp } from '@/context/AppContext';
import DisclaimerBanner from '@/components/DisclaimerBanner';
import { Info, Target, Database, Mail, TrendingUp } from 'lucide-react';

export default function AboutPage() {
  const { t } = useApp();

  const sections = [
    {
      icon: <Info className="w-6 h-6" />,
      title: t('aboutTitle'),
      content: t('aboutContent'),
      color: 'bg-primary-100 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300',
    },
    {
      icon: <Target className="w-6 h-6" />,
      title: t('ourMission'),
      content: t('ourMissionContent'),
      color: 'bg-accent-100 dark:bg-accent-900/30 text-accent-700 dark:text-accent-300',
    },
    {
      icon: <Database className="w-6 h-6" />,
      title: t('dataDisclaimer'),
      content: t('dataDisclaimerContent'),
      color: 'bg-warning-100 dark:bg-warning-900/30 text-warning-700 dark:text-warning-300',
    },
    {
      icon: <Mail className="w-6 h-6" />,
      title: t('contactUs'),
      content: t('contactContent'),
      color: 'bg-primary-100 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300',
    },
  ];

  return (
    <div className="min-h-screen max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center gap-3 mb-2">
        <div className="w-10 h-10 rounded-xl bg-primary-600 flex items-center justify-center">
          <TrendingUp className="w-5 h-5 text-white" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-gray-100">{t('aboutTitle')}</h1>
      </div>

      <div className="mt-8 space-y-5">
        {sections.map((section, i) => (
          <div key={i} className="card p-6 animate-slide-up" style={{ animationDelay: `${i * 50}ms` }}>
            <div className="flex items-start gap-4">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${section.color}`}>
                {section.icon}
              </div>
              <div className="flex-1">
                <h2 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-2">{section.title}</h2>
                <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">{section.content}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-8">
        <DisclaimerBanner />
      </div>
    </div>
  );
}
