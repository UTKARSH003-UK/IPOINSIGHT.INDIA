import { useState, useMemo } from 'react';
import { useApp } from '@/context/AppContext';
import { ipos, sectors, type IPOStatus, type IPOType } from '@/data/ipos';
import IPOCard from '@/components/IPOCard';
import DisclaimerBanner from '@/components/DisclaimerBanner';
import { Search, SlidersHorizontal, TrendingUp, Clock, CheckCircle2, XCircle } from 'lucide-react';

type Tab = 'all' | IPOStatus;

export default function HomePage() {
  const { t } = useApp();
  const [search, setSearch] = useState('');
  const [activeTab, setActiveTab] = useState<Tab>('all');
  const [typeFilter, setTypeFilter] = useState<IPOType | 'all'>('all');
  const [sectorFilter, setSectorFilter] = useState<string>('all');

  const filteredIpos = useMemo(() => {
    return ipos.filter((ipo) => {
      const matchesSearch = ipo.name.toLowerCase().includes(search.toLowerCase());
      const matchesTab = activeTab === 'all' || ipo.status === activeTab;
      const matchesType = typeFilter === 'all' || ipo.type === typeFilter;
      const matchesSector = sectorFilter === 'all' || ipo.sector === sectorFilter;
      return matchesSearch && matchesTab && matchesType && matchesSector;
    });
  }, [search, activeTab, typeFilter, sectorFilter]);

  const tabs: { key: Tab; label: string; icon: React.ReactNode }[] = [
    { key: 'all', label: t('all'), icon: <TrendingUp className="w-4 h-4" /> },
    { key: 'upcoming', label: t('upcoming'), icon: <Clock className="w-4 h-4" /> },
    { key: 'open', label: t('openNow'), icon: <TrendingUp className="w-4 h-4" /> },
    { key: 'closed', label: t('closed'), icon: <XCircle className="w-4 h-4" /> },
    { key: 'listed', label: t('listed'), icon: <CheckCircle2 className="w-4 h-4" /> },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary-900 via-primary-800 to-primary-950">
        <div className="absolute inset-0 opacity-10" style={{
          backgroundImage: 'radial-gradient(circle at 20% 50%, white 1px, transparent 1px), radial-gradient(circle at 80% 20%, white 1px, transparent 1px)',
          backgroundSize: '40px 40px, 30px 30px',
        }} />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24">
          <div className="text-center max-w-3xl mx-auto">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/10 backdrop-blur-sm mb-6">
              <span className="w-2 h-2 rounded-full bg-accent-400 animate-pulse" />
              <span className="text-sm text-white/90 font-medium">NSE / BSE • Mainboard & SME</span>
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-4 leading-tight">
              {t('heroTitle')}
            </h1>
            <p className="text-lg sm:text-xl text-white/80 mb-8 leading-relaxed">
              {t('heroTagline')}
            </p>
            <div className="relative max-w-xl mx-auto">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder={t('searchPlaceholder')}
                className="w-full pl-12 pr-4 py-4 bg-white dark:bg-gray-900 rounded-2xl text-gray-900 dark:text-gray-100 placeholder-gray-400 shadow-xl focus:outline-none focus:ring-2 focus:ring-accent-400 transition-all duration-200"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Main content */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Tabs */}
        <div className="flex items-center gap-2 mb-6 overflow-x-auto pb-1">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium whitespace-nowrap transition-all duration-200 ${
                activeTab === tab.key
                  ? 'bg-primary-600 text-white shadow-md'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700'
              }`}
            >
              {tab.icon}
              {tab.label}
            </button>
          ))}
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 mb-6">
          <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400 shrink-0">
            <SlidersHorizontal className="w-4 h-4" />
            <span className="font-medium">{t('filters')}:</span>
          </div>
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value as IPOType | 'all')}
            className="input-field max-w-[160px] text-sm py-2"
          >
            <option value="all">{t('allTypes')}</option>
            <option value="Mainboard">{t('mainboard')}</option>
            <option value="SME">{t('sme')}</option>
          </select>
          <select
            value={sectorFilter}
            onChange={(e) => setSectorFilter(e.target.value)}
            className="input-field max-w-[220px] text-sm py-2"
          >
            <option value="all">{t('allSectors')}</option>
            {sectors.map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
          <div className="text-sm text-gray-500 dark:text-gray-400 ml-auto">
            {filteredIpos.length} {filteredIpos.length === 1 ? 'IPO' : 'IPOs'}
          </div>
        </div>

        {/* IPO Grid */}
        {filteredIpos.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredIpos.map((ipo) => (
              <IPOCard key={ipo.id} ipo={ipo} />
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <p className="text-gray-400 dark:text-gray-500 text-lg">{t('noResults')}</p>
          </div>
        )}

        <div className="mt-8">
          <DisclaimerBanner />
        </div>
      </section>
    </div>
  );
}
