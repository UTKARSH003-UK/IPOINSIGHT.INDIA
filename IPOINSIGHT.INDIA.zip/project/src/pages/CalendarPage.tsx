import { useApp } from '@/context/AppContext';
import { useRouter } from '@/router/Router';
import { ipos } from '@/data/ipos';
import { LogoPlaceholder, StatusBadge } from '@/components/IPOCard';
import DisclaimerBanner from '@/components/DisclaimerBanner';
import { CalendarDays, ChevronRight } from 'lucide-react';

function formatDate(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

function getMonthKey(dateStr: string): string {
  const d = new Date(dateStr);
  return `${d.getFullYear()}-${String(d.getMonth()).padStart(2, '0')}`;
}

function getMonthLabel(monthKey: string): string {
  const [year, month] = monthKey.split('-').map(Number);
  return new Date(year, month, 1).toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });
}

export default function CalendarPage() {
  const { t } = useApp();
  const { navigate } = useRouter();

  type EventType = 'open' | 'close' | 'allotment' | 'listing';
  const events: { ipo: typeof ipos[0]; date: string; type: EventType }[] = [
    ...ipos.map((ipo) => ({ ipo, date: ipo.openDate, type: 'open' as EventType })),
    ...ipos.map((ipo) => ({ ipo, date: ipo.closeDate, type: 'close' as EventType })),
    ...ipos.map((ipo) => ({ ipo, date: ipo.allotmentDate, type: 'allotment' as EventType })),
    ...ipos.map((ipo) => ({ ipo, date: ipo.listingDate, type: 'listing' as EventType })),
  ].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  const monthKeys = Array.from(new Set(events.map((e) => getMonthKey(e.date))));

  const eventLabelMap: Record<string, string> = {
    open: t('openDate'),
    close: t('closeDate'),
    allotment: t('allotmentDate'),
    listing: t('listingDate'),
  };

  const eventColorMap: Record<string, string> = {
    open: 'bg-accent-500',
    close: 'bg-error-500',
    allotment: 'bg-primary-500',
    listing: 'bg-warning-500',
  };

  return (
    <div className="min-h-screen max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center gap-3 mb-2">
        <div className="w-10 h-10 rounded-xl bg-primary-600 flex items-center justify-center">
          <CalendarDays className="w-5 h-5 text-white" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-gray-100">{t('calendarTitle')}</h1>
      </div>
      <p className="text-gray-500 dark:text-gray-400 mb-6">{t('calendarSubtitle')}</p>

      {/* Legend */}
      <div className="flex flex-wrap items-center gap-4 mb-6">
        {(['open', 'close', 'allotment', 'listing'] as const).map((type) => (
          <div key={type} className="flex items-center gap-2">
            <div className={`w-3 h-3 rounded-full ${eventColorMap[type]}`} />
            <span className="text-sm text-gray-600 dark:text-gray-400">{eventLabelMap[type]}</span>
          </div>
        ))}
      </div>

      {/* Calendar by month */}
      <div className="space-y-8">
        {monthKeys.map((monthKey) => {
          const monthEvents = events.filter((e) => getMonthKey(e.date) === monthKey);
          return (
            <div key={monthKey}>
              <h2 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-3 sticky top-16 bg-white dark:bg-gray-950 py-2 z-10">
                {getMonthLabel(monthKey)}
              </h2>
              <div className="space-y-2">
                {monthEvents.map((event, i) => (
                  <div
                    key={i}
                    onClick={() => navigate(`/ipo/${event.ipo.id}`)}
                    className="card card-hover p-4 cursor-pointer flex items-center gap-4 animate-slide-up"
                  >
                    <div className="text-center shrink-0 w-14">
                      <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">
                        {new Date(event.date).getDate()}
                      </p>
                      <p className="text-xs text-gray-400 dark:text-gray-500">
                        {new Date(event.date).toLocaleDateString('en-IN', { weekday: 'short' })}
                      </p>
                    </div>
                    <div className={`w-1 h-12 rounded-full ${eventColorMap[event.type]}`} />
                    <div className="flex-1 flex items-center gap-3">
                      <LogoPlaceholder color={event.ipo.logoColor} text={event.ipo.logoText} size="sm" />
                      <div>
                        <p className="text-sm font-semibold text-gray-900 dark:text-gray-100">{event.ipo.name}</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">
                          {eventLabelMap[event.type]} • {formatDate(event.date)}
                        </p>
                      </div>
                    </div>
                    <StatusBadge status={event.ipo.status} />
                    <ChevronRight className="w-5 h-5 text-gray-300 dark:text-gray-600 shrink-0" />
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-8">
        <DisclaimerBanner />
      </div>
    </div>
  );
}
