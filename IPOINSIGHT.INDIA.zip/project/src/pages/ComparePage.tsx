import { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { ipos } from '@/data/ipos';
import { LogoPlaceholder, StatusBadge, TypeBadge } from '@/components/IPOCard';
import DisclaimerBanner from '@/components/DisclaimerBanner';
import { Plus, X, GitCompare } from 'lucide-react';

export default function ComparePage() {
  const { t } = useApp();
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [showSelector, setShowSelector] = useState(false);

  const selectedIpos = ipos.filter((ipo) => selectedIds.includes(ipo.id));
  const availableIpos = ipos.filter((ipo) => !selectedIds.includes(ipo.id));

  const addIPO = (id: string) => {
    if (selectedIds.length < 3) {
      setSelectedIds([...selectedIds, id]);
      setShowSelector(false);
    }
  };

  const removeIPO = (id: string) => {
    setSelectedIds(selectedIds.filter((sid) => sid !== id));
  };

  const compareRows: { label: string; render: (ipo: typeof ipos[0]) => string | number }[] = [
    { label: t('sector'), render: (ipo) => ipo.sector },
    { label: t('exchange'), render: (ipo) => ipo.exchange },
    { label: t('type'), render: (ipo) => ipo.type },
    { label: t('priceBand'), render: (ipo) => `${t('rs')}${ipo.priceBandLow}-${ipo.priceBandHigh}` },
    { label: t('lotSize'), render: (ipo) => ipo.lotSize },
    { label: t('minimumInvestment'), render: (ipo) => `${t('rs')}${(ipo.lotSize * ipo.priceBandHigh).toLocaleString('en-IN')}` },
    { label: t('totalIssueSize'), render: (ipo) => `${t('rs')}${ipo.issueSize} ${t('crore')}` },
    { label: t('freshIssue'), render: (ipo) => `${t('rs')}${ipo.freshIssue} ${t('crore')}` },
    { label: t('offerForSale'), render: (ipo) => `${t('rs')}${ipo.offerForSale} ${t('crore')}` },
    { label: t('openDate'), render: (ipo) => new Date(ipo.openDate).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) },
    { label: t('closeDate'), render: (ipo) => new Date(ipo.closeDate).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) },
    { label: t('listingDate'), render: (ipo) => new Date(ipo.listingDate).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) },
    { label: t('registrar'), render: (ipo) => ipo.registrar },
    { label: `${t('qib')} ${t('subscriptionStatus')}`, render: (ipo) => `${ipo.subscription.qib}x` },
    { label: `${t('nii')} ${t('subscriptionStatus')}`, render: (ipo) => `${ipo.subscription.nii}x` },
    { label: `${t('retail')} ${t('subscriptionStatus')}`, render: (ipo) => `${ipo.subscription.retail}x` },
    { label: t('gmp'), render: (ipo) => ipo.gmp > 0 ? `+${t('rs')}${ipo.gmp}` : 'N/A' },
    { label: t('revenue') + ' (FY26)', render: (ipo) => `${ipo.financials[ipo.financials.length - 1]?.revenue ?? 'N/A'}` },
    { label: t('profit') + ' (FY26)', render: (ipo) => `${ipo.financials[ipo.financials.length - 1]?.profit ?? 'N/A'}` },
    { label: t('eps') + ' (FY26)', render: (ipo) => `${ipo.financials[ipo.financials.length - 1]?.eps ?? 'N/A'}` },
  ];

  return (
    <div className="min-h-screen max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center gap-3 mb-2">
        <div className="w-10 h-10 rounded-xl bg-primary-600 flex items-center justify-center">
          <GitCompare className="w-5 h-5 text-white" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-gray-100">{t('compareTitle')}</h1>
      </div>
      <p className="text-gray-500 dark:text-gray-400 mb-6">{t('compareSubtitle')}</p>

      {selectedIpos.length === 0 && (
        <div className="card p-12 text-center">
          <GitCompare className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-4" />
          <p className="text-gray-400 dark:text-gray-500 mb-4">{t('selectAtLeast')}</p>
        </div>
      )}

      {selectedIpos.length > 0 && (
        <div className="card p-4 sm:p-6 overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr>
                <th className="text-left p-3 min-w-[140px]"></th>
                {selectedIpos.map((ipo) => (
                  <th key={ipo.id} className="text-left p-3 min-w-[200px]">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-3">
                        <LogoPlaceholder color={ipo.logoColor} text={ipo.logoText} size="sm" />
                        <div>
                          <p className="font-semibold text-gray-900 dark:text-gray-100 text-sm">{ipo.name}</p>
                          <div className="flex items-center gap-1.5 mt-1">
                            <StatusBadge status={ipo.status} />
                            <TypeBadge type={ipo.type} />
                          </div>
                        </div>
                      </div>
                      <button
                        onClick={() => removeIPO(ipo.id)}
                        className="p-1 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors shrink-0"
                      >
                        <X className="w-4 h-4 text-gray-400" />
                      </button>
                    </div>
                  </th>
                ))}
                {selectedIpos.length < 3 && (
                  <th className="p-3 min-w-[120px]">
                    <button
                      onClick={() => setShowSelector(true)}
                      className="flex items-center gap-2 px-3 py-2 rounded-lg border-2 border-dashed border-gray-300 dark:border-gray-700 text-sm text-gray-500 dark:text-gray-400 hover:border-primary-400 hover:text-primary-500 transition-colors w-full"
                    >
                      <Plus className="w-4 h-4" />
                      {t('addIPO')}
                    </button>
                  </th>
                )}
              </tr>
            </thead>
            <tbody>
              {compareRows.map((row, i) => (
                <tr key={i} className={i % 2 === 0 ? 'bg-gray-50/50 dark:bg-gray-800/30' : ''}>
                  <td className="p-3 text-sm font-medium text-gray-500 dark:text-gray-400">{row.label}</td>
                  {selectedIpos.map((ipo) => (
                    <td key={ipo.id} className="p-3 text-sm font-semibold text-gray-900 dark:text-gray-100">
                      {row.render(ipo)}
                    </td>
                  ))}
                  {selectedIpos.length < 3 && <td />}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* IPO Selector Modal */}
      {showSelector && availableIpos.length > 0 && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 animate-fade-in" onClick={() => setShowSelector(false)}>
          <div className="card p-6 max-w-md w-full animate-scale-in" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-gray-900 dark:text-gray-100">{t('selectIPO')}</h3>
              <button onClick={() => setShowSelector(false)} className="p-1 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800">
                <X className="w-5 h-5 text-gray-400" />
              </button>
            </div>
            <div className="space-y-2 max-h-80 overflow-y-auto">
              {availableIpos.map((ipo) => (
                <button
                  key={ipo.id}
                  onClick={() => addIPO(ipo.id)}
                  className="flex items-center gap-3 w-full p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors text-left"
                >
                  <LogoPlaceholder color={ipo.logoColor} text={ipo.logoText} size="sm" />
                  <div>
                    <p className="text-sm font-medium text-gray-900 dark:text-gray-100">{ipo.name}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">{ipo.sector}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      <div className="mt-8">
        <DisclaimerBanner />
      </div>
    </div>
  );
}
