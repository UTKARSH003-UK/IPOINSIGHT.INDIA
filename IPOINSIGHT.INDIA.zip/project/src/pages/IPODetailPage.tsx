import { useApp } from '@/context/AppContext';
import { useRouter } from '@/router/Router';
import { ipos } from '@/data/ipos';
import { BarChart, PieChart, SubscriptionBar } from '@/components/Charts';
import DisclaimerBanner from '@/components/DisclaimerBanner';
import { StatusBadge, TypeBadge, LogoPlaceholder } from '@/components/IPOCard';
import {
  ArrowLeft, Calendar, Building2, Users, FileText, TrendingUp,
  AlertTriangle, ExternalLink, IndianRupee, PieChart as PieIcon,
  BarChart3, Activity, BookOpen, Link2, ShieldCheck,
} from 'lucide-react';

function formatDate(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

export default function IPODetailPage({ id }: { id: string }) {
  const { t } = useApp();
  const { navigate } = useRouter();
  const ipo = ipos.find((i) => i.id === id);

  if (!ipo) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <p className="text-gray-400 dark:text-gray-500 text-lg mb-4">IPO not found.</p>
        <button onClick={() => navigate('/')} className="btn-primary">{t('backToHome')}</button>
      </div>
    );
  }

  const minInvest = ipo.lotSize * ipo.priceBandHigh;
  const pieColors = ['#2563eb', '#10b981', '#f59e0b', '#7c3aed', '#ef4444', '#06b6d4'];

  const dateEvents = [
    { label: t('openDate'), date: ipo.openDate, icon: <Calendar className="w-4 h-4" /> },
    { label: t('closeDate'), date: ipo.closeDate, icon: <Calendar className="w-4 h-4" /> },
    { label: t('allotmentDate'), date: ipo.allotmentDate, icon: <CheckCircle className="w-4 h-4" /> },
    { label: t('refundDate'), date: ipo.refundDate, icon: <IndianRupee className="w-4 h-4" /> },
    { label: t('listingDate'), date: ipo.listingDate, icon: <TrendingUp className="w-4 h-4" /> },
  ];

  return (
    <div className="min-h-screen max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Back button */}
      <button
        onClick={() => navigate('/')}
        className="flex items-center gap-1.5 text-sm text-gray-500 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400 transition-colors mb-6"
      >
        <ArrowLeft className="w-4 h-4" />
        {t('backToHome')}
      </button>

      {/* Header */}
      <div className="card p-6 mb-6">
        <div className="flex flex-col sm:flex-row items-start gap-4">
          <LogoPlaceholder color={ipo.logoColor} text={ipo.logoText} size="lg" />
          <div className="flex-1">
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <StatusBadge status={ipo.status} />
              <TypeBadge type={ipo.type} />
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-gray-100">{ipo.name}</h1>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{ipo.sector} • {ipo.exchange}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left column - main content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Overview */}
          <section className="card p-6">
            <div className="flex items-center gap-2 mb-4">
              <Building2 className="w-5 h-5 text-primary-600 dark:text-primary-400" />
              <h2 className="section-title">{t('overview')}</h2>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed mb-5">{ipo.description}</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <p className="text-xs text-gray-400 dark:text-gray-500 mb-1">{t('sector')}</p>
                <p className="text-sm font-medium text-gray-900 dark:text-gray-100">{ipo.sector}</p>
              </div>
              <div>
                <p className="text-xs text-gray-400 dark:text-gray-500 mb-1">{t('exchange')}</p>
                <p className="text-sm font-medium text-gray-900 dark:text-gray-100">{ipo.exchange}</p>
              </div>
              <div>
                <p className="text-xs text-gray-400 dark:text-gray-500 mb-1">{t('leadManagers')}</p>
                <p className="text-sm font-medium text-gray-900 dark:text-gray-100">{ipo.leadManagers.join(', ')}</p>
              </div>
              <div>
                <p className="text-xs text-gray-400 dark:text-gray-500 mb-1">{t('registrar')}</p>
                <p className="text-sm font-medium text-gray-900 dark:text-gray-100">{ipo.registrar}</p>
              </div>
            </div>
          </section>

          {/* Key Dates Timeline */}
          <section className="card p-6">
            <div className="flex items-center gap-2 mb-4">
              <Calendar className="w-5 h-5 text-primary-600 dark:text-primary-400" />
              <h2 className="section-title">{t('keyDates')}</h2>
            </div>
            <div className="relative">
              <div className="absolute left-[19px] top-0 bottom-0 w-0.5 bg-gray-200 dark:bg-gray-800" />
              <div className="space-y-4">
                {dateEvents.map((event, i) => (
                  <div key={i} className="flex items-center gap-4 relative">
                    <div className="w-10 h-10 rounded-full bg-primary-50 dark:bg-primary-900/30 border-2 border-primary-200 dark:border-primary-800 flex items-center justify-center text-primary-600 dark:text-primary-400 shrink-0 z-10">
                      {event.icon}
                    </div>
                    <div className="flex-1">
                      <p className="text-xs text-gray-400 dark:text-gray-500">{event.label}</p>
                      <p className="text-sm font-semibold text-gray-900 dark:text-gray-100">{formatDate(event.date)}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* Issue Details */}
          <section className="card p-6">
            <div className="flex items-center gap-2 mb-4">
              <FileText className="w-5 h-5 text-primary-600 dark:text-primary-400" />
              <h2 className="section-title">{t('issueDetails')}</h2>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              <div className="p-3 rounded-lg bg-gray-50 dark:bg-gray-800/50">
                <p className="text-xs text-gray-400 dark:text-gray-500 mb-1">{t('priceBand')}</p>
                <p className="text-sm font-bold text-gray-900 dark:text-gray-100">{t('rs')}{ipo.priceBandLow}-{ipo.priceBandHigh}</p>
              </div>
              <div className="p-3 rounded-lg bg-gray-50 dark:bg-gray-800/50">
                <p className="text-xs text-gray-400 dark:text-gray-500 mb-1">{t('lotSize')}</p>
                <p className="text-sm font-bold text-gray-900 dark:text-gray-100">{ipo.lotSize}</p>
              </div>
              <div className="p-3 rounded-lg bg-gray-50 dark:bg-gray-800/50">
                <p className="text-xs text-gray-400 dark:text-gray-500 mb-1">{t('minimumInvestment')}</p>
                <p className="text-sm font-bold text-gray-900 dark:text-gray-100">{t('rs')}{minInvest.toLocaleString('en-IN')}</p>
              </div>
              <div className="p-3 rounded-lg bg-gray-50 dark:bg-gray-800/50">
                <p className="text-xs text-gray-400 dark:text-gray-500 mb-1">{t('freshIssue')}</p>
                <p className="text-sm font-bold text-gray-900 dark:text-gray-100">{t('rs')}{ipo.freshIssue} {t('crore')}</p>
              </div>
              <div className="p-3 rounded-lg bg-gray-50 dark:bg-gray-800/50">
                <p className="text-xs text-gray-400 dark:text-gray-500 mb-1">{t('offerForSale')}</p>
                <p className="text-sm font-bold text-gray-900 dark:text-gray-100">{t('rs')}{ipo.offerForSale} {t('crore')}</p>
              </div>
              <div className="p-3 rounded-lg bg-gray-50 dark:bg-gray-800/50">
                <p className="text-xs text-gray-400 dark:text-gray-500 mb-1">{t('totalIssueSize')}</p>
                <p className="text-sm font-bold text-gray-900 dark:text-gray-100">{t('rs')}{ipo.issueSize} {t('crore')}</p>
              </div>
            </div>

            {/* Reservation */}
            <div className="mt-5">
              <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">{t('reservation')}</p>
              <div className="grid grid-cols-3 gap-3">
                <div className="text-center p-3 rounded-lg bg-primary-50 dark:bg-primary-900/20">
                  <p className="text-xs text-primary-600 dark:text-primary-400">{t('qib')}</p>
                  <p className="text-lg font-bold text-primary-700 dark:text-primary-300">{ipo.reservation.qib}%</p>
                </div>
                <div className="text-center p-3 rounded-lg bg-accent-50 dark:bg-accent-900/20">
                  <p className="text-xs text-accent-600 dark:text-accent-400">{t('nii')}</p>
                  <p className="text-lg font-bold text-accent-700 dark:text-accent-300">{ipo.reservation.nii}%</p>
                </div>
                <div className="text-center p-3 rounded-lg bg-warning-50 dark:bg-warning-900/20">
                  <p className="text-xs text-warning-600 dark:text-warning-400">{t('retail')}</p>
                  <p className="text-lg font-bold text-warning-700 dark:text-warning-300">{ipo.reservation.retail}%</p>
                </div>
              </div>
            </div>
          </section>

          {/* Prospectus Summary */}
          <section className="card p-6">
            <div className="flex items-center gap-2 mb-4">
              <BookOpen className="w-5 h-5 text-primary-600 dark:text-primary-400" />
              <h2 className="section-title">{t('prospectusSummary')}</h2>
            </div>
            <div className="space-y-5">
              <div>
                <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">{t('businessModel')}</p>
                <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">{ipo.businessModel}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">{t('objectsOfIssue')}</p>
                <ul className="space-y-1.5">
                  {ipo.objectsOfIssue.map((obj, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-gray-600 dark:text-gray-400">
                      <span className="w-1.5 h-1.5 rounded-full bg-primary-500 mt-1.5 shrink-0" />
                      {obj}
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">{t('riskFactors')}</p>
                <ul className="space-y-1.5">
                  {ipo.riskFactors.map((risk, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-gray-600 dark:text-gray-400">
                      <AlertTriangle className="w-4 h-4 text-warning-500 mt-0.5 shrink-0" />
                      {risk}
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1.5">{t('competitors')}</p>
                <div className="flex flex-wrap gap-2">
                  {ipo.competitors.map((comp, i) => (
                    <span key={i} className="badge bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400">
                      {comp}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </section>

          {/* Promoters & Shareholding */}
          <section className="card p-6">
            <div className="flex items-center gap-2 mb-4">
              <Users className="w-5 h-5 text-primary-600 dark:text-primary-400" />
              <h2 className="section-title">{t('promotersShareholding')}</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <PieChart
                  data={ipo.promoters.map((p, i) => ({
                    label: p.name,
                    value: p.postIssue,
                    color: pieColors[i % pieColors.length],
                  }))}
                />
              </div>
              <div>
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-gray-200 dark:border-gray-800">
                      <th className="text-left py-2 font-medium text-gray-500 dark:text-gray-400">{t('promoterNames')}</th>
                      <th className="text-right py-2 font-medium text-gray-500 dark:text-gray-400">{t('preIssue')}</th>
                      <th className="text-right py-2 font-medium text-gray-500 dark:text-gray-400">{t('postIssue')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {ipo.promoters.map((p, i) => (
                      <tr key={i} className="border-b border-gray-100 dark:border-gray-800/50">
                        <td className="py-2.5 text-gray-900 dark:text-gray-100">
                          <div className="flex items-center gap-2">
                            <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: pieColors[i % pieColors.length] }} />
                            {p.name}
                          </div>
                        </td>
                        <td className="py-2.5 text-right text-gray-600 dark:text-gray-400">{p.preIssue}%</td>
                        <td className="py-2.5 text-right font-semibold text-gray-900 dark:text-gray-100">{p.postIssue}%</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                <div className="mt-4 p-3 rounded-lg bg-gray-50 dark:bg-gray-800/50">
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    <span className="font-medium text-gray-700 dark:text-gray-300">{t('lockInDetails')}: </span>
                    {ipo.lockInDetails}
                  </p>
                </div>
              </div>
            </div>
          </section>

          {/* Financials */}
          <section className="card p-6">
            <div className="flex items-center gap-2 mb-4">
              <BarChart3 className="w-5 h-5 text-primary-600 dark:text-primary-400" />
              <h2 className="section-title">{t('financials')}</h2>
            </div>
            <div className="space-y-6">
              <div>
                <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">{t('revenue')} & {t('profit')} ({t('crore')})</p>
                <BarChart
                  data={ipo.financials.map((f) => ({ label: f.year, value: f.revenue }))}
                  height={180}
                  formatValue={(v) => `${v}`}
                />
              </div>
              <div>
                <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">{t('ebitda')} ({t('crore')})</p>
                <BarChart
                  data={ipo.financials.map((f) => ({ label: f.year, value: f.ebitda, color: 'linear-gradient(to top, #059669, #34d399)' }))}
                  height={180}
                  formatValue={(v) => `${v}`}
                />
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-gray-200 dark:border-gray-800">
                      <th className="text-left py-2 font-medium text-gray-500 dark:text-gray-400">Metric</th>
                      {ipo.financials.map((f) => (
                        <th key={f.year} className="text-right py-2 font-medium text-gray-500 dark:text-gray-400">{f.year}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      { label: t('revenue'), key: 'revenue' as const },
                      { label: t('profit'), key: 'profit' as const },
                      { label: t('ebitda'), key: 'ebitda' as const },
                      { label: t('netWorth'), key: 'netWorth' as const },
                      { label: t('debt'), key: 'debt' as const },
                      { label: `${t('roe')} (%)`, key: 'roe' as const },
                      { label: `${t('roce')} (%)`, key: 'roce' as const },
                      { label: `${t('eps')} (Rs)`, key: 'eps' as const },
                    ].map((row) => (
                      <tr key={row.key} className="border-b border-gray-100 dark:border-gray-800/50">
                        <td className="py-2.5 text-gray-600 dark:text-gray-400">{row.label}</td>
                        {ipo.financials.map((f) => (
                          <td key={f.year} className="py-2.5 text-right font-medium text-gray-900 dark:text-gray-100">
                            {f[row.key].toLocaleString('en-IN')}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </section>
        </div>

        {/* Right column - sidebar */}
        <div className="space-y-6">
          {/* Valuation */}
          <section className="card p-6">
            <div className="flex items-center gap-2 mb-4">
              <TrendingUp className="w-5 h-5 text-primary-600 dark:text-primary-400" />
              <h2 className="section-title">{t('valuation')}</h2>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-200 dark:border-gray-800">
                    <th className="text-left py-2 font-medium text-gray-500 dark:text-gray-400">{t('companyName')}</th>
                    <th className="text-right py-2 font-medium text-gray-500 dark:text-gray-400">{t('pe')}</th>
                    <th className="text-right py-2 font-medium text-gray-500 dark:text-gray-400">{t('marketCap')}</th>
                  </tr>
                </thead>
                <tbody>
                  {ipo.peerComparison.map((peer, i) => (
                    <tr key={i} className={`border-b border-gray-100 dark:border-gray-800/50 ${peer.name === ipo.name ? 'bg-primary-50 dark:bg-primary-900/20' : ''}`}>
                      <td className="py-2.5 text-gray-900 dark:text-gray-100 font-medium">{peer.name}</td>
                      <td className="py-2.5 text-right text-gray-600 dark:text-gray-400">{peer.pe}</td>
                      <td className="py-2.5 text-right text-gray-600 dark:text-gray-400">{peer.marketCap.toLocaleString('en-IN')}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          {/* Live Data */}
          <section className="card p-6">
            <div className="flex items-center gap-2 mb-4">
              <Activity className="w-5 h-5 text-accent-600 dark:text-accent-400" />
              <h2 className="section-title">{t('liveData')}</h2>
            </div>
            <div className="space-y-4">
              <div>
                <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">{t('subscriptionStatus')}</p>
                <SubscriptionBar
                  qib={ipo.subscription.qib}
                  nii={ipo.subscription.nii}
                  retail={ipo.subscription.retail}
                  total={ipo.subscription.total}
                />
              </div>
              <div className="p-4 rounded-xl bg-warning-50 dark:bg-warning-900/20 border border-warning-200 dark:border-warning-800/50">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-warning-700 dark:text-warning-300 font-medium">{t('gmp')}</p>
                    <p className="text-2xl font-bold text-warning-800 dark:text-warning-200 mt-1">
                      {ipo.gmp > 0 ? `+${t('rs')}${ipo.gmp}` : 'N/A'}
                    </p>
                  </div>
                  <ShieldCheck className="w-8 h-8 text-warning-400" />
                </div>
                <p className="text-xs text-warning-600 dark:text-warning-400 mt-2">
                  {ipo.gmpStatus === 'none' ? 'No GMP data available' : 'Unofficial — not verified by SEBI/NSE/BSE'}
                </p>
              </div>
            </div>
          </section>

          {/* Official Links */}
          <section className="card p-6">
            <div className="flex items-center gap-2 mb-4">
              <Link2 className="w-5 h-5 text-primary-600 dark:text-primary-400" />
              <h2 className="section-title">{t('officialLinks')}</h2>
            </div>
            <div className="space-y-2">
              <a href={ipo.rhpLink} target="_blank" rel="noopener noreferrer" className="flex items-center justify-between p-3 rounded-lg bg-gray-50 dark:bg-gray-800/50 hover:bg-primary-50 dark:hover:bg-primary-900/20 transition-colors group">
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{t('rhp')}</span>
                <ExternalLink className="w-4 h-4 text-gray-400 group-hover:text-primary-500" />
              </a>
              <a href={ipo.drhpLink} target="_blank" rel="noopener noreferrer" className="flex items-center justify-between p-3 rounded-lg bg-gray-50 dark:bg-gray-800/50 hover:bg-primary-50 dark:hover:bg-primary-900/20 transition-colors group">
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{t('drhp')}</span>
                <ExternalLink className="w-4 h-4 text-gray-400 group-hover:text-primary-500" />
              </a>
              <a href={ipo.allotmentLink} target="_blank" rel="noopener noreferrer" className="flex items-center justify-between p-3 rounded-lg bg-gray-50 dark:bg-gray-800/50 hover:bg-primary-50 dark:hover:bg-primary-900/20 transition-colors group">
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{t('allotmentStatus')}</span>
                <ExternalLink className="w-4 h-4 text-gray-400 group-hover:text-primary-500" />
              </a>
            </div>
          </section>

          <DisclaimerBanner />
        </div>
      </div>
    </div>
  );
}

function CheckCircle({ className }: { className?: string }) {
  return <ShieldCheck className={className} />;
}
