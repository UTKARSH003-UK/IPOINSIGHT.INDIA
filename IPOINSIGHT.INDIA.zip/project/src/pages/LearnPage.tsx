import { useApp } from '@/context/AppContext';
import DisclaimerBanner from '@/components/DisclaimerBanner';
import { GraduationCap, Package, TrendingUp, Users, Smartphone, BookOpen } from 'lucide-react';

export default function LearnPage() {
  const { t } = useApp();

  const guides = [
    {
      icon: <GraduationCap className="w-6 h-6" />,
      title: t('whatIsIPO'),
      content: t('whatIsIPOContent'),
      color: 'bg-primary-100 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300',
    },
    {
      icon: <Package className="w-6 h-6" />,
      title: t('lotSizeGuide'),
      content: t('lotSizeContent'),
      color: 'bg-accent-100 dark:bg-accent-900/30 text-accent-700 dark:text-accent-300',
    },
    {
      icon: <TrendingUp className="w-6 h-6" />,
      title: t('gmpGuide'),
      content: t('gmpContent'),
      color: 'bg-warning-100 dark:bg-warning-900/30 text-warning-700 dark:text-warning-300',
    },
    {
      icon: <Users className="w-6 h-6" />,
      title: t('anchorInvestors'),
      content: t('anchorInvestorsContent'),
      color: 'bg-primary-100 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300',
    },
    {
      icon: <Smartphone className="w-6 h-6" />,
      title: t('uppiGuide'),
      content: t('uppiContent'),
      color: 'bg-accent-100 dark:bg-accent-900/30 text-accent-700 dark:text-accent-300',
    },
  ];

  return (
    <div className="min-h-screen max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center gap-3 mb-2">
        <div className="w-10 h-10 rounded-xl bg-primary-600 flex items-center justify-center">
          <BookOpen className="w-5 h-5 text-white" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-gray-100">{t('learnTitle')}</h1>
      </div>
      <p className="text-gray-500 dark:text-gray-400 mb-8">{t('learnSubtitle')}</p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {guides.map((guide, i) => (
          <div key={i} className="card p-6 animate-slide-up" style={{ animationDelay: `${i * 50}ms` }}>
            <div className="flex items-start gap-4">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${guide.color}`}>
                {guide.icon}
              </div>
              <div className="flex-1">
                <h2 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-2">{guide.title}</h2>
                <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">{guide.content}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-8">
        <DisclaimerBanner />
      </div>
    </div>
  );
}
