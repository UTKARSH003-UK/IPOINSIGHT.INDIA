interface BarChartProps {
  data: { label: string; value: number; color?: string }[];
  unit?: string;
  height?: number;
  formatValue?: (v: number) => string;
}

export function BarChart({ data, unit = '', height = 200, formatValue }: BarChartProps) {
  const maxVal = Math.max(...data.map((d) => d.value), 1);
  const barWidth = Math.max(40, Math.min(80, 400 / data.length - 16));

  return (
    <div className="w-full">
      <div className="flex items-end justify-around gap-3" style={{ height }}>
        {data.map((d, i) => {
          const barHeight = (d.value / maxVal) * (height - 40);
          return (
            <div key={i} className="flex flex-col items-center gap-2 flex-1">
              <span className="text-xs font-semibold text-gray-700 dark:text-gray-300 whitespace-nowrap">
                {formatValue ? formatValue(d.value) : `${d.value}${unit}`}
              </span>
              <div
                className="w-full max-w-[60px] rounded-t-lg transition-all duration-500 hover:opacity-80"
                style={{
                  height: `${barHeight}px`,
                  background: d.color || 'linear-gradient(to top, #2563eb, #60a5fa)',
                  minHeight: '4px',
                }}
              />
            </div>
          );
        })}
      </div>
      <div className="flex justify-around gap-3 mt-2">
        {data.map((d, i) => (
          <div key={i} className="flex-1 text-center">
            <span className="text-xs text-gray-500 dark:text-gray-400">{d.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

interface PieChartProps {
  data: { label: string; value: number; color: string }[];
  size?: number;
}

export function PieChart({ data, size = 200 }: PieChartProps) {
  const total = data.reduce((sum, d) => sum + d.value, 0);
  let cumulative = 0;
  const radius = size / 2;
  const center = radius;
  const strokeWidth = 0;

  const segments = data.map((d) => {
    const fraction = d.value / total;
    const startAngle = cumulative * 2 * Math.PI - Math.PI / 2;
    cumulative += fraction;
    const endAngle = cumulative * 2 * Math.PI - Math.PI / 2;

    const x1 = center + radius * Math.cos(startAngle);
    const y1 = center + radius * Math.sin(startAngle);
    const x2 = center + radius * Math.cos(endAngle);
    const y2 = center + radius * Math.sin(endAngle);

    const largeArc = fraction > 0.5 ? 1 : 0;

    return {
      path: `M ${center} ${center} L ${x1} ${y1} A ${radius} ${radius} 0 ${largeArc} 1 ${x2} ${y2} Z`,
      color: d.color,
      label: d.label,
      value: d.value,
    };
  });

  return (
    <div className="flex flex-col sm:flex-row items-center gap-6">
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="shrink-0">
        {segments.map((seg, i) => (
          <path key={i} d={seg.path} fill={seg.color} stroke="white" strokeWidth={strokeWidth} className="transition-opacity duration-200 hover:opacity-80" />
        ))}
      </svg>
      <div className="flex flex-col gap-2">
        {data.map((d, i) => (
          <div key={i} className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: d.color }} />
            <span className="text-sm text-gray-600 dark:text-gray-400">
              {d.label}: <span className="font-semibold text-gray-900 dark:text-gray-100">{d.value}%</span>
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

interface SubscriptionBarProps {
  qib: number;
  nii: number;
  retail: number;
  total: number;
}

export function SubscriptionBar({ qib, nii, retail, total }: SubscriptionBarProps) {
  const categories = [
    { label: 'QIB', value: qib, color: '#2563eb' },
    { label: 'NII', value: nii, color: '#10b981' },
    { label: 'Retail', value: retail, color: '#f59e0b' },
    { label: 'Total', value: total, color: '#7c3aed' },
  ];

  const maxVal = Math.max(...categories.map((c) => c.value), 1);

  return (
    <div className="space-y-3">
      {categories.map((cat, i) => {
        const widthPct = (cat.value / maxVal) * 100;
        return (
          <div key={i}>
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm font-medium text-gray-600 dark:text-gray-400">{cat.label}</span>
              <span className="text-sm font-bold text-gray-900 dark:text-gray-100">{cat.value}x</span>
            </div>
            <div className="h-6 bg-gray-100 dark:bg-gray-800 rounded-lg overflow-hidden">
              <div
                className="h-full rounded-lg transition-all duration-700 ease-out flex items-center justify-end pr-2"
                style={{ width: `${Math.max(widthPct, 2)}%`, backgroundColor: cat.color }}
              >
                {widthPct > 15 && (
                  <span className="text-xs text-white font-medium">{cat.value}x</span>
                )}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
