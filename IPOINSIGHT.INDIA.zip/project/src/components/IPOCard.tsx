import type { IPO, IPOStatus } from '@/data/ipos';
import { useApp } from '@/context/AppContext';
import { useRouter } from '@/router/Router';
import { Calendar, Layers, IndianRupee, ChevronRight } from 'lucide-react';

export function StatusBadge({ status }: { status: IPOStatus }) {
  const { t } = useApp();
  const labelMap: Record<IPOStatus, string> = {
    upcoming: t('upcoming'),
    open: t('openNow'),
    closed: t('closed'),
    listed: t('listed'),
  };
  const classMap: Record<IPOStatus, string> = {
    upcoming: 'badge-upcoming',
    open: 'badge-open',
    closed: 'badge-closed',
    listed: 'badge-listed',
  };
  return <span className={`badge ${classMap[status]}`}>{labelMap[status]}</span>;
}

export function TypeBadge({ type }: { type: string }) {
  return (
    <span className="badge bg-primary-50 text-primary-700 dark:bg-primary-900/30 dark:text-primary-300">
      {type}
    </span>
  );
}

export function LogoPlaceholder({ color, text, size = 'md' }: { color: string; text: string; size?: 'sm' | 'md' | 'lg' }) {
  const sizeClass = size === 'sm' ? 'w-10 h-10 text-sm' : size === 'lg' ? 'w-16 h-16 text-xl' : 'w-12 h-12 text-base';
  return (
    <div
      className={`${sizeClass} rounded-xl flex items-center justify-center font-bold text-white shrink-0`}
      style={{ backgroundColor: color }}
    >
      {text}
    </div>
  );
}

function formatDate(dateStr: string): string {
  const date = new Date(dateStr);
  return date.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

export default function IPOCard({ ipo }: { ipo: IPO }) {
  const { t } = useApp();
  const { navigate } = useRouter();
  const minInvest = ipo.lotSize * ipo.priceBandHigh;

  return (
    <div
      onClick={() => navigate(`/ipo/${ipo.id}`)}
      className="card card-hover p-5 cursor-pointer animate-slide-up"
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <LogoPlaceholder color={ipo.logoColor} text={ipo.logoText} />
          <div>
            <h3 className="font-semibold text-gray-900 dark:text-gray-100 leading-tight">{ipo.name}</h3>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{ipo.sector}</p>
          </div>
        </div>
        <div className="flex flex-col items-end gap-1.5">
          <StatusBadge status={ipo.status} />
          <TypeBadge type={ipo.type} />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="space-y-1">
          <p className="text-xs text-gray-400 dark:text-gray-500">{t('priceBand')}</p>
          <p className="text-sm font-semibold text-gray-900 dark:text-gray-100">
            {t('rs')}{ipo.priceBandLow} - {t('rs')}{ipo.priceBandHigh}
          </p>
        </div>
        <div className="space-y-1">
          <p className="text-xs text-gray-400 dark:text-gray-500">{t('lotSize')}</p>
          <p className="text-sm font-semibold text-gray-900 dark:text-gray-100">{ipo.lotSize} shares</p>
        </div>
        <div className="space-y-1">
          <p className="text-xs text-gray-400 dark:text-gray-500">{t('issueSize')}</p>
          <p className="text-sm font-semibold text-gray-900 dark:text-gray-100">
            {t('rs')}{ipo.issueSize} {t('crore')}
          </p>
        </div>
        <div className="space-y-1">
          <p className="text-xs text-gray-400 dark:text-gray-500">{t('minimumInvestment')}</p>
          <p className="text-sm font-semibold text-gray-900 dark:text-gray-100">
            {t('rs')}{minInvest.toLocaleString('en-IN')}
          </p>
        </div>
      </div>

      <div className="flex items-center gap-4 text-xs text-gray-500 dark:text-gray-400 mb-4 pb-4 border-b border-gray-100 dark:border-gray-800">
        <div className="flex items-center gap-1.5">
          <Calendar className="w-3.5 h-3.5" />
          <span>{formatDate(ipo.openDate)} - {formatDate(ipo.closeDate)}</span>
        </div>
      </div>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5 text-xs text-gray-500 dark:text-gray-400">
          <Layers className="w-3.5 h-3.5" />
          <span>{ipo.exchange}</span>
        </div>
        <div className="flex items-center gap-1 text-sm font-medium text-primary-600 dark:text-primary-400">
          {t('viewDetails')}
          <ChevronRight className="w-4 h-4" />
        </div>
      </div>

      {ipo.status === 'listed' && ipo.listingGain !== undefined && (
        <div className="mt-3 px-3 py-2 rounded-lg bg-accent-50 dark:bg-accent-900/20 flex items-center justify-between">
          <span className="text-xs text-accent-700 dark:text-accent-300">{t('listingDate')}</span>
          <span className="text-sm font-bold text-accent-700 dark:text-accent-300">
            +{ipo.listingGain}% ({t('rs')}{ipo.listingPrice})
          </span>
        </div>
      )}
    </div>
  );
}
