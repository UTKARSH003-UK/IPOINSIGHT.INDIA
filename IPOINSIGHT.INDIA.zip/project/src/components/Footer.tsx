import { useApp } from '@/context/AppContext';
import { useRouter } from '@/router/Router';
import { TrendingUp, AlertCircle } from 'lucide-react';

export default function Footer() {
  const { t } = useApp();
  const { navigate } = useRouter();

  return (
    <footer className="mt-16 border-t border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary-600 to-primary-800 flex items-center justify-center">
                <TrendingUp className="w-4 h-4 text-white" />
              </div>
              <span className="font-bold text-gray-900 dark:text-white">IPO Insight India</span>
            </div>
            <p className="text-sm text-gray-500 dark:text-gray-400 max-w-xs">
              {t('madeFor')}. {t('heroTagline')}
            </p>
          </div>

          <div>
            <h3 className="font-semibold text-gray-900 dark:text-gray-100 mb-3 text-sm">{t('quickLinks')}</h3>
            <ul className="space-y-2">
              {[
                { label: t('home'), path: '/' },
                { label: t('compare'), path: '/compare' },
                { label: t('calendar'), path: '/calendar' },
                { label: t('learn'), path: '/learn' },
                { label: t('about'), path: '/about' },
              ].map((link) => (
                <li key={link.path}>
                  <button
                    onClick={() => navigate(link.path)}
                    className="text-sm text-gray-500 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400 transition-colors"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-gray-900 dark:text-gray-100 mb-3 text-sm">{t('resources')}</h3>
            <ul className="space-y-2">
              <li>
                <a href="https://www.sebi.gov.in" target="_blank" rel="noopener noreferrer" className="text-sm text-gray-500 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400 transition-colors">
                  SEBI
                </a>
              </li>
              <li>
                <a href="https://www.nseindia.com" target="_blank" rel="noopener noreferrer" className="text-sm text-gray-500 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400 transition-colors">
                  NSE India
                </a>
              </li>
              <li>
                <a href="https://www.bseindia.com" target="_blank" rel="noopener noreferrer" className="text-sm text-gray-500 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400 transition-colors">
                  BSE India
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-8 p-4 rounded-xl bg-warning-50 dark:bg-warning-900/20 border border-warning-200 dark:border-warning-800/50">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-warning-600 dark:text-warning-400 shrink-0 mt-0.5" />
            <p className="text-sm text-warning-800 dark:text-warning-200">{t('disclaimer')}</p>
          </div>
        </div>

        <p className="mt-6 text-center text-xs text-gray-400 dark:text-gray-500">
          © {new Date().getFullYear()} IPO Insight India. {t('dataDisclaimerContent')}
        </p>
      </div>
    </footer>
  );
}
