import { useApp } from '@/context/AppContext';
import { AlertCircle } from 'lucide-react';

export default function DisclaimerBanner() {
  const { t } = useApp();
  return (
    <div className="rounded-xl bg-warning-50 dark:bg-warning-900/20 border border-warning-200 dark:border-warning-800/50 p-3 sm:p-4">
      <div className="flex items-start gap-2.5">
        <AlertCircle className="w-4 h-4 text-warning-600 dark:text-warning-400 shrink-0 mt-0.5" />
        <p className="text-xs sm:text-sm text-warning-800 dark:text-warning-200 leading-relaxed">
          {t('disclaimer')}
        </p>
      </div>
    </div>
  );
}
