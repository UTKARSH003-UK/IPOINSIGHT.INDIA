export type Language = 'en' | 'hi';

export const translations = {
  en: {
    // Nav
    home: 'Home',
    compare: 'Compare',
    calendar: 'Calendar',
    learn: 'Learn',
    about: 'About',
    searchPlaceholder: 'Search IPO by name...',
    darkMode: 'Dark Mode',
    lightMode: 'Light Mode',

    // Hero
    heroTitle: 'IPO Insight India',
    heroTagline: 'Track Indian IPOs with clarity — Mainboard & SME, explained simply for beginner investors.',

    // Tabs
    upcoming: 'Upcoming',
    openNow: 'Open Now',
    closed: 'Closed',
    listed: 'Listed',
    all: 'All',

    // Filters
    filters: 'Filters',
    type: 'Type',
    sector: 'Sector',
    allTypes: 'All Types',
    allSectors: 'All Sectors',
    mainboard: 'Mainboard',
    sme: 'SME',
    noResults: 'No IPOs found matching your filters.',

    // IPO Card
    priceBand: 'Price Band',
    lotSize: 'Lot Size',
    issueSize: 'Issue Size',
    openDate: 'Open',
    closeDate: 'Close',
    listingDate: 'Listing',
    viewDetails: 'View Details',
    minimumInvestment: 'Min. Investment',

    // Detail page
    overview: 'Overview',
    keyDates: 'Key Dates',
    issueDetails: 'Issue Details',
    prospectusSummary: 'Prospectus Summary',
    promotersShareholding: 'Promoters & Shareholding',
    financials: 'Financials (Last 3 Years)',
    valuation: 'Valuation',
    liveData: 'Live Data',
    subscriptionStatus: 'Subscription Status',
    gmp: 'GMP (Unofficial)',
    officialLinks: 'Official Links',
    companyDescription: 'Company Description',
    exchange: 'Exchange',
    leadManagers: 'Lead Managers',
    registrar: 'Registrar',
    businessModel: 'Business Model',
    objectsOfIssue: 'Objects of the Issue',
    riskFactors: 'Key Risk Factors',
    competitors: 'Competitors',
    promoterNames: 'Promoter Names',
    preIssue: 'Pre-Issue',
    postIssue: 'Post-Issue',
    lockInDetails: 'Lock-in Details',
    freshIssue: 'Fresh Issue',
    offerForSale: 'Offer for Sale',
    totalIssueSize: 'Total Issue Size',
    reservation: 'Reservation',
    qib: 'QIB',
    nii: 'NII',
    retail: 'Retail',
    revenue: 'Revenue',
    profit: 'Profit',
    ebitda: 'EBITDA',
    netWorth: 'Net Worth',
    debt: 'Debt',
    roe: 'ROE',
    roce: 'ROCE',
    eps: 'EPS',
    peVsPeers: 'P/E vs Peers',
    companyName: 'Company',
    pe: 'P/E',
    marketCap: 'Market Cap (Cr)',
    rhp: 'RHP',
    drhp: 'DRHP',
    allotmentStatus: 'Allotment Status',
    allotmentDate: 'Allotment',
    refundDate: 'Refund',
    backToHome: 'Back to Home',

    // Compare
    compareTitle: 'Compare IPOs',
    compareSubtitle: 'Compare up to 3 IPOs side by side',
    selectIPO: 'Select IPO',
    addIPO: 'Add IPO to Compare',
    remove: 'Remove',
    selectAtLeast: 'Select at least 2 IPOs to compare.',

    // Calendar
    calendarTitle: 'IPO Calendar',
    calendarSubtitle: 'Upcoming and recent IPO events at a glance',

    // Learn
    learnTitle: 'Learn IPO Basics',
    learnSubtitle: 'Simple guides for beginner investors',
    whatIsIPO: 'What is an IPO?',
    whatIsIPOContent: 'An IPO (Initial Public Offering) is when a private company offers its shares to the public for the first time. This allows the company to raise money from investors and get listed on a stock exchange like NSE or BSE. After the IPO, anyone can buy and sell the company\'s shares on the exchange.',
    lotSizeGuide: 'What is Lot Size?',
    lotSizeContent: 'In an IPO, you cannot buy just 1 share. You must apply in multiples of a "lot". For example, if the lot size is 30 and the price band is Rs 450-500, the minimum investment is 30 x 500 = Rs 15,000. You can apply for 1 lot, 2 lots, 3 lots, etc.',
    gmpGuide: 'What is GMP?',
    gmpContent: 'GMP (Grey Market Premium) is the premium at which IPO shares are traded in the unofficial grey market before listing. For example, if the IPO price is Rs 500 and GMP is Rs 100, the grey market expects the share to list at around Rs 600. GMP is unofficial and not regulated — treat it as a sentiment indicator, not a guarantee.',
    anchorInvestors: 'What are Anchor Investors?',
    anchorInvestorsContent: 'Anchor investors are institutional investors (like mutual funds and banks) who are allotted shares a day before the IPO opens to the public. They commit large amounts (minimum Rs 10 crore each) and help build confidence in the IPO. Their shares are locked in for 90 days (30 days for SME IPOs).',
    uppiGuide: 'How to Apply Through UPI',
    uppiContent: 'You can apply for an IPO using UPI (Google Pay, PhonePe, Paytm, etc.) as a payment method. Steps: 1) Log into your broker app or bank\'s IPO section. 2) Select the IPO and enter the number of lots. 3) Enter your UPI ID and confirm. 4) Approve the mandate request on your UPI app. 5) The amount is blocked in your account until allotment. If you don\'t get shares, the amount is released automatically.',

    // About
    aboutTitle: 'About IPO Insight India',
    aboutContent: 'IPO Insight India is an educational platform that helps beginner investors understand and track Indian IPOs. We provide clear, simple information about Mainboard and SME IPOs on NSE and BSE, including key dates, financials, valuations, and subscription data.',
    ourMission: 'Our Mission',
    ourMissionContent: 'To make IPO investing accessible and understandable for every Indian investor, regardless of their experience level. We break down complex financial jargon into simple language.',
    dataDisclaimer: 'Data Disclaimer',
    dataDisclaimerContent: 'All data shown on this platform is sample data for educational purposes. It may not reflect real-time market conditions. Always verify information from official sources before making any investment decision.',
    contactUs: 'Contact Us',
    contactContent: 'This is a demo project. For any queries, please refer to the official SEBI and exchange websites.',

    // Disclaimer
    disclaimer: 'For information and education only. This is not investment advice. GMP is unofficial. Please read the RHP before investing.',

    // Footer
    quickLinks: 'Quick Links',
    resources: 'Resources',
    madeFor: 'Made for Indian investors',

    // Units
    crore: 'Cr',
    rs: 'Rs',
    times: 'x',
  },
  hi: {
    // Nav
    home: 'होम',
    compare: 'तुलना',
    calendar: 'कैलेंडर',
    learn: 'सीखें',
    about: 'परिचय',
    searchPlaceholder: 'IPO नाम से खोजें...',
    darkMode: 'डार्क मोड',
    lightMode: 'लाइट मोड',

    // Hero
    heroTitle: 'IPO इनसाइट इंडिया',
    heroTagline: 'भारतीय IPO को सरलता से ट्रैक करें — मेनबोर्ड और SME, नए निवेशकों के लिए आसान भाषा में।',

    // Tabs
    upcoming: 'आने वाले',
    openNow: 'खुले हुए',
    closed: 'बंद',
    listed: 'लिस्टेड',
    all: 'सभी',

    // Filters
    filters: 'फ़िल्टर',
    type: 'प्रकार',
    sector: 'सेक्टर',
    allTypes: 'सभी प्रकार',
    allSectors: 'सभी सेक्टर',
    mainboard: 'मेनबोर्ड',
    sme: 'SME',
    noResults: 'आपके फ़िल्टर से मेल खाते कोई IPO नहीं मिले।',

    // IPO Card
    priceBand: 'प्राइस बैंड',
    lotSize: 'लॉट साइज़',
    issueSize: 'इश्यू साइज़',
    openDate: 'खुलना',
    closeDate: 'बंद होना',
    listingDate: 'लिस्टिंग',
    viewDetails: 'विवरण देखें',
    minimumInvestment: 'न्यूनतम निवेश',

    // Detail page
    overview: 'अवलोकन',
    keyDates: 'मुख्य तिथियां',
    issueDetails: 'इश्यू विवरण',
    prospectusSummary: 'प्रॉस्पेक्टस सारांश',
    promotersShareholding: 'प्रमोटर और शेयरहोल्डिंग',
    financials: 'वित्तीय (पिछले 3 वर्ष)',
    valuation: 'मूल्यांकन',
    liveData: 'लाइव डेटा',
    subscriptionStatus: 'सब्सक्रिप्शन स्थिति',
    gmp: 'GMP (अनौपचारिक)',
    officialLinks: 'आधिकारिक लिंक',
    companyDescription: 'कंपनी विवरण',
    exchange: 'एक्सचेंज',
    leadManagers: 'लीड मैनेजर',
    registrar: 'रजिस्ट्रार',
    businessModel: 'बिज़नेस मॉडल',
    objectsOfIssue: 'इश्यू के उद्देश्य',
    riskFactors: 'मुख्य जोखिम कारक',
    competitors: 'प्रतिस्पर्धी',
    promoterNames: 'प्रमोटर नाम',
    preIssue: 'इश्यू पूर्व',
    postIssue: 'इश्यू के बाद',
    lockInDetails: 'लॉक-इन विवरण',
    freshIssue: 'फ्रेश इश्यू',
    offerForSale: 'ऑफर फॉर सेल',
    totalIssueSize: 'कुल इश्यू साइज़',
    reservation: 'आरक्षण',
    qib: 'QIB',
    nii: 'NII',
    retail: 'रिटेल',
    revenue: 'राजस्व',
    profit: 'लाभ',
    ebitda: 'EBITDA',
    netWorth: 'नेट वर्थ',
    debt: 'कर्ज़',
    roe: 'ROE',
    roce: 'ROCE',
    eps: 'EPS',
    peVsPeers: 'P/E बनाम पीयर्स',
    companyName: 'कंपनी',
    pe: 'P/E',
    marketCap: 'मार्केट कैप (Cr)',
    rhp: 'RHP',
    drhp: 'DRHP',
    allotmentStatus: 'अलॉटमेंट स्टेटस',
    allotmentDate: 'अलॉटमेंट',
    refundDate: 'रिफंड',
    backToHome: 'होम पर वापस',

    // Compare
    compareTitle: 'IPO तुलना',
    compareSubtitle: '2-3 IPO को एक साथ तुलना करें',
    selectIPO: 'IPO चुनें',
    addIPO: 'तुलना के लिए IPO जोड़ें',
    remove: 'हटाएं',
    selectAtLeast: 'तुलना के लिए कम से कम 2 IPO चुनें।',

    // Calendar
    calendarTitle: 'IPO कैलेंडर',
    calendarSubtitle: 'आने वाले और हाल के IPO कार्यक्रम एक नज़र में',

    // Learn
    learnTitle: 'IPO बेसिक्स सीखें',
    learnSubtitle: 'नए निवेशकों के लिए सरल गाइड',
    whatIsIPO: 'IPO क्या है?',
    whatIsIPOContent: 'IPO (इनिशियल पब्लिक ऑफरिंग) तब होता है जब कोई प्राइवेट कंपनी पहली बार अपने शेयर आम जनता को ऑफर करती है। इससे कंपनी निवेशकों से पैसा जुटा सकती है और NSE या BSE जैसे स्टॉक एक्सचेंज पर लिस्ट हो सकती है। IPO के बाद, कोई भी व्यक्ति एक्सचेंज पर कंपनी के शेयर खरीद और बेच सकता है।',
    lotSizeGuide: 'लॉट साइज़ क्या है?',
    lotSizeContent: 'IPO में आप केवल 1 शेयर नहीं खरीद सकते। आपको "लॉट" के गुणकों में आवेदन करना होगा। उदाहरण के लिए, यदि लॉट साइज़ 30 है और प्राइस बैंड 450-500 रुपये है, तो न्यूनतम निवेश 30 x 500 = 15,000 रुपये होगा। आप 1 लॉट, 2 लॉट, 3 लॉट आदि के लिए आवेदन कर सकते हैं।',
    gmpGuide: 'GMP क्या है?',
    gmpContent: 'GMP (ग्रे मार्केट प्रीमियम) वह प्रीमियम है जिस पर IPO के शेयर लिस्टिंग से पहले अनौपचारिक ग्रे मार्केट में ट्रेड होते हैं। उदाहरण के लिए, यदि IPO प्राइस 500 रुपये है और GMP 100 रुपये है, तो ग्रे मार्केट शेयर को लगभग 600 रुपये पर लिस्ट होने की उम्मीद करता है। GMP अनौपचारिक है और विनियमित नहीं है — इसे एक भावना संकेतक के रूप में देखें, गारंटी नहीं।',
    anchorInvestors: 'एंकर इन्वेस्टर क्या हैं?',
    anchorInvestorsContent: 'एंकर इन्वेस्टर संस्थागत निवेशक (जैसे म्यूचुअल फंड और बैंक) होते हैं जिन्हें IPO आम जनता के लिए खुलने से एक दिन पहले शेयर आवंटित किए जाते हैं। वे बड़ी राशि (न्यूनतम 10 करोड़ रुपये प्रत्येक) का प्रतिबद्धता दिखाते हैं और IPO में विश्वास बनाने में मदद करते हैं। उनके शेयर 90 दिनों के लिए लॉक-इन रहते हैं (SME IPO के लिए 30 दिन)।',
    uppiGuide: 'UPI से कैसे आवेदन करें',
    uppiContent: 'आप UPI (Google Pay, PhonePe, Paytm आदि) का उपयोग करके IPO के लिए आवेदन कर सकते हैं। चरण: 1) अपने ब्रोकर ऐप या बैंक के IPO सेक्शन में लॉगिन करें। 2) IPO चुनें और लॉट की संख्या दर्ज करें। 3) अपना UPI ID दर्ज करें और पुष्टि करें। 4) अपने UPI ऐप पर मैंडेट अनुरोध स्वीकार करें। 5) अलॉटमेंट तक राशि आपके खाते में ब्लॉक रहेगी। यदि आपको शेयर नहीं मिले, तो राशि स्वतः रिलीज़ हो जाएगी।',

    // About
    aboutTitle: 'IPO इनसाइट इंडिया के बारे में',
    aboutContent: 'IPO इनसाइट इंडिया एक शैक्षिक प्लेटफॉर्म है जो नए निवेशकों को भारतीय IPO को समझने और ट्रैक करने में मदद करता है। हम NSE और BSE पर मेनबोर्ड और SME IPO की स्पष्ट, सरल जानकारी प्रदान करते हैं, जिसमें मुख्य तिथियां, वित्तीय, मूल्यांकन और सब्सक्रिप्शन डेटा शामिल हैं।',
    ourMission: 'हमारा मिशन',
    ourMissionContent: 'हर भारतीय निवेशक के लिए IPO निवेश को सुलभ और समझने योग्य बनाना, चाहे उनका अनुभव जो भी हो। हम जटिक्ल वित्तीय शब्दावली को सरल भाषा में समझाते हैं।',
    dataDisclaimer: 'डेटा अस्वीकरण',
    dataDisclaimerContent: 'इस प्लेटफॉर्म पर दिखाया गया सभी डेटा शैक्षिक उद्देश्यों के लिए सैंपल डेटा है। यह वास्तविक समय की बाज़ार स्थितियों को नहीं दर्शा सकता। कोई भी निवेश निर्णय लेने से पहले हमेशा आधिकारिक स्रोतों से जानकारी सत्यापित करें।',
    contactUs: 'संपर्क करें',
    contactContent: 'यह एक डेमो प्रोजेक्ट है। किसी भी प्रश्न के लिए, कृपया आधिकारिक SEBI और एक्सचेंज वेबसाइट देखें।',

    // Disclaimer
    disclaimer: 'केवल जानकारी और शिक्षा के लिए। यह निवेश सलाह नहीं है। GMP अनौपचारिक है। कृपया निवेश से पहले RHP पढ़ें।',

    // Footer
    quickLinks: 'क्विक लिंक',
    resources: 'संसाधन',
    madeFor: 'भारतीय निवेशकों के लिए बनाया गया',

    // Units
    crore: 'Cr',
    rs: 'रु',
    times: 'x',
  },
};

export type TranslationKey = keyof typeof translations.en;
