export type IPOStatus = 'upcoming' | 'open' | 'closed' | 'listed';
export type IPOType = 'Mainboard' | 'SME';

export interface FinancialYear {
  year: string;
  revenue: number;
  profit: number;
  ebitda: number;
  netWorth: number;
  debt: number;
  roe: number;
  roce: number;
  eps: number;
}

export interface ShareholdingParty {
  name: string;
  preIssue: number;
  postIssue: number;
}

export interface IPO {
  id: string;
  name: string;
  type: IPOType;
  sector: string;
  exchange: string;
  status: IPOStatus;
  logoColor: string;
  logoText: string;
  priceBandLow: number;
  priceBandHigh: number;
  lotSize: number;
  issueSize: number;
  issueSizeUnit: 'Cr' | 'Rs';
  freshIssue: number;
  offerForSale: number;
  openDate: string;
  closeDate: string;
  allotmentDate: string;
  refundDate: string;
  listingDate: string;
  listingPrice?: number;
  listingGain?: number;
  description: string;
  leadManagers: string[];
  registrar: string;
  businessModel: string;
  objectsOfIssue: string[];
  riskFactors: string[];
  competitors: string[];
  promoters: ShareholdingParty[];
  lockInDetails: string;
  financials: FinancialYear[];
  reservation: {
    qib: number;
    nii: number;
    retail: number;
  };
  peerComparison: {
    name: string;
    pe: number;
    marketCap: number;
  }[];
  subscription: {
    qib: number;
    nii: number;
    retail: number;
    total: number;
  };
  gmp: number;
  gmpStatus: 'active' | 'none' | 'unverified';
  rhpLink: string;
  drhpLink: string;
  allotmentLink: string;
}

export const ipos: IPO[] = [
  {
    id: 'tata-technologies',
    name: 'Tata Technologies',
    type: 'Mainboard',
    sector: 'IT / Engineering Services',
    exchange: 'NSE / BSE',
    status: 'listed',
    logoColor: '#1e3a8a',
    logoText: 'TT',
    priceBandLow: 450,
    priceBandHigh: 500,
    lotSize: 30,
    issueSize: 3042,
    issueSizeUnit: 'Cr',
    freshIssue: 357,
    offerForSale: 2685,
    openDate: '2023-11-22',
    closeDate: '2023-11-24',
    allotmentDate: '2023-11-29',
    refundDate: '2023-11-30',
    listingDate: '2023-12-01',
    listingPrice: 1200,
    listingGain: 140,
    description: 'Tata Technologies is a leading global engineering services company providing product development and digital transformation solutions to global automotive and aerospace OEMs. A subsidiary of Tata Motors, it serves 12 of the top 15 automotive OEMs globally.',
    leadManagers: ['JM Financial', 'Citigroup Global Markets', 'BofA Securities'],
    registrar: 'Link Intime India',
    businessModel: 'The company provides outsourced engineering services and digital transformation solutions across the product development value chain. Revenue comes from services (80%) and products (20%).',
    objectsOfIssue: [
      'Achieve the benefits of listing on the stock exchanges',
      'Carry out the sale of up to 60,850,278 equity shares by the selling shareholders',
      'Enhance brand visibility and provide liquidity to existing shareholders',
    ],
    riskFactors: [
      'Heavy dependence on top 5 clients which contribute 76% of revenue',
      'Concentration in automotive sector which is cyclical',
      'Dependence on parent Tata Motors for a significant portion of revenue',
      'Currency exchange rate fluctuations affecting international revenue',
    ],
    competitors: ['KPIT Technologies', 'Tata Elxsi', 'L&T Technology Services', 'Cyient'],
    promoters: [
      { name: 'Tata Motors', preIssue: 53.4, postIssue: 41.6 },
      { name: 'Alpha TC Holdings', preIssue: 11.3, postIssue: 8.8 },
      { name: 'Tata Capital Growth Fund', preIssue: 8.6, postIssue: 6.7 },
      { name: 'Public Shareholders', preIssue: 26.7, postIssue: 42.9 },
    ],
    lockInDetails: 'Promoter shares have a lock-in period of 6 months from the date of allotment as per SEBI regulations.',
    financials: [
      { year: 'FY21', revenue: 2384, profit: 261, ebitda: 389, netWorth: 1042, debt: 485, roe: 28.5, roce: 31.2, eps: 6.5 },
      { year: 'FY22', revenue: 3526, profit: 447, ebitda: 624, netWorth: 1437, debt: 412, roe: 33.8, roce: 36.5, eps: 11.1 },
      { year: 'FY23', revenue: 4419, profit: 629, ebitda: 896, netWorth: 1987, debt: 378, roe: 35.2, roce: 38.9, eps: 15.6 },
    ],
    reservation: { qib: 50, nii: 15, retail: 35 },
    peerComparison: [
      { name: 'Tata Elxsi', pe: 64.2, marketCap: 41200 },
      { name: 'KPIT Technologies', pe: 55.8, marketCap: 12800 },
      { name: 'L&T Tech Services', pe: 38.5, marketCap: 15600 },
      { name: 'Tata Technologies', pe: 32.1, marketCap: 3042 },
    ],
    subscription: { qib: 41.2, nii: 32.7, retail: 16.5, total: 28.4 },
    gmp: 280,
    gmpStatus: 'unverified',
    rhpLink: 'https://www.sebi.gov.in',
    drhpLink: 'https://www.nseindia.com',
    allotmentLink: 'https://www.linkintime.com',
  },
  {
    id: 'ireda',
    name: 'Indian Renewable Energy Development Agency',
    type: 'Mainboard',
    sector: 'NBFC / Green Energy',
    exchange: 'NSE / BSE',
    status: 'listed',
    logoColor: '#059669',
    logoText: 'IRE',
    priceBandLow: 30,
    priceBandHigh: 32,
    lotSize: 460,
    issueSize: 2150,
    issueSizeUnit: 'Cr',
    freshIssue: 2150,
    offerForSale: 0,
    openDate: '2023-11-21',
    closeDate: '2023-11-23',
    allotmentDate: '2023-11-28',
    refundDate: '2023-11-29',
    listingDate: '2023-11-30',
    listingPrice: 50,
    listingGain: 56.25,
    description: 'IREDA is a government-owned NBFC under the Ministry of New and Renewable Energy. It provides financial assistance for renewable energy projects including solar, wind, hydro, and bio-energy across India.',
    leadManagers: ['IDBI Capital Market', 'SBI Capital Markets', 'BOB Capital Markets'],
    registrar: 'Bigshare Services',
    businessModel: 'IREDA lends to renewable energy projects and earns interest income. It also provides consultancy and advisory services. 95% of revenue comes from interest on loans.',
    objectsOfIssue: [
      'Augment capital base to meet future capital requirements',
      'Provide long-term financial resources for lending to renewable energy projects',
      'Enhance visibility and brand image among stakeholders',
    ],
    riskFactors: [
      'Dependent on government policies and subsidies for renewable energy',
      'Exposure to project execution risks in renewable energy sector',
      'Asset-liability mismatch due to long-tenure loans',
      'Competition from commercial banks and other NBFCs',
    ],
    competitors: ['PFC', 'REC', 'Tata Cleantech Capital', 'Adani Green Energy'],
    promoters: [
      { name: 'President of India (GoI)', preIssue: 100, postIssue: 75 },
      { name: 'Public Shareholders', preIssue: 0, postIssue: 25 },
    ],
    lockInDetails: 'Government holding has a lock-in period of 1 year as per SEBI regulations for PSUs.',
    financials: [
      { year: 'FY21', revenue: 2104, profit: 299, ebitda: 420, netWorth: 3197, debt: 18200, roe: 9.4, roce: 12.1, eps: 1.7 },
      { year: 'FY22', revenue: 2879, profit: 634, ebitda: 890, netWorth: 3822, debt: 23100, roe: 16.6, roce: 18.5, eps: 3.1 },
      { year: 'FY23', revenue: 3448, profit: 864, ebitda: 1120, netWorth: 4686, debt: 27500, roe: 18.4, roce: 20.8, eps: 4.0 },
    ],
    reservation: { qib: 50, nii: 15, retail: 35 },
    peerComparison: [
      { name: 'PFC', pe: 8.5, marketCap: 35000 },
      { name: 'REC', pe: 9.2, marketCap: 28000 },
      { name: 'Tata Cleantech', pe: 12.4, marketCap: 1800 },
      { name: 'IREDA', pe: 10.5, marketCap: 2150 },
    ],
    subscription: { qib: 104.6, nii: 25.5, retail: 8.2, total: 38.7 },
    gmp: 14,
    gmpStatus: 'unverified',
    rhpLink: 'https://www.sebi.gov.in',
    drhpLink: 'https://www.nseindia.com',
    allotmentLink: 'https://www.bigshareonline.com',
  },
  {
    id: 'tbo-tek',
    name: 'TBO Tek',
    type: 'Mainboard',
    sector: 'Travel Technology',
    exchange: 'NSE / BSE',
    status: 'listed',
    logoColor: '#2563eb',
    logoText: 'TB',
    priceBandLow: 875,
    priceBandHigh: 920,
    lotSize: 16,
    issueSize: 1550,
    issueSizeUnit: 'Cr',
    freshIssue: 400,
    offerForSale: 1150,
    openDate: '2024-05-08',
    closeDate: '2024-05-10',
    allotmentDate: '2024-05-14',
    refundDate: '2024-05-15',
    listingDate: '2024-05-17',
    listingPrice: 1390,
    listingGain: 51.08,
    description: 'TBO Tek is a leading B2B travel distribution platform connecting travel agents, tour operators, and corporates with airlines, hotels, and other travel suppliers across 120+ countries.',
    leadManagers: ['Axis Capital', 'Kotak Mahindra Capital', 'JM Financial'],
    registrar: 'Kfintech',
    businessModel: 'TBO operates a two-sided B2B travel platform. It earns commission on flight bookings and hotel reservations. Revenue split: Air (55%), Hotels (40%), Others (5%).',
    objectsOfIssue: [
      'Expansion of product offerings and customer base',
      'Investment in technology and platform development',
      'Acquisition of complementary businesses',
      'General corporate purposes',
    ],
    riskFactors: [
      'Highly competitive travel technology market',
      'Dependence on airline and hotel partnerships',
      'Seasonal fluctuations in travel demand',
      'Regulatory changes in international travel',
    ],
    competitors: ['Yatra Online', 'Easy Trip Planners', 'RateGain Travel', 'Mystifly'],
    promoters: [
      { name: 'Gaurav Bhatnagar', preIssue: 28.5, postIssue: 21.2 },
      { name: 'Ankush Nijhawan', preIssue: 28.5, postIssue: 21.2 },
      { name: 'General Atlantic', preIssue: 15.0, postIssue: 11.2 },
      { name: 'Public Shareholders', preIssue: 28.0, postIssue: 46.4 },
    ],
    lockInDetails: 'Promoter shares subject to 6-month lock-in. PE investor shares subject to 6-month lock-in as per SEBI ICDR regulations.',
    financials: [
      { year: 'FY21', revenue: 385, profit: 42, ebitda: 78, netWorth: 285, debt: 15, roe: 14.7, roce: 16.2, eps: 3.8 },
      { year: 'FY22', revenue: 689, profit: 87, ebitda: 152, netWorth: 412, debt: 12, roe: 21.1, roce: 23.5, eps: 7.2 },
      { year: 'FY23', revenue: 1024, profit: 148, ebitda: 234, netWorth: 587, debt: 8, roe: 25.2, roce: 28.1, eps: 11.5 },
    ],
    reservation: { qib: 75, nii: 10, retail: 15 },
    peerComparison: [
      { name: 'Easy Trip Planners', pe: 45.2, marketCap: 8200 },
      { name: 'Yatra Online', pe: 28.5, marketCap: 2400 },
      { name: 'RateGain Travel', pe: 52.3, marketCap: 3800 },
      { name: 'TBO Tek', pe: 38.7, marketCap: 1550 },
    ],
    subscription: { qib: 27.5, nii: 12.8, retail: 6.1, total: 15.2 },
    gmp: 420,
    gmpStatus: 'unverified',
    rhpLink: 'https://www.sebi.gov.in',
    drhpLink: 'https://www.bseindia.com',
    allotmentLink: 'https://www.kfintech.com',
  },
  {
    id: 'bharti-airtel-fpo',
    name: 'Bharti Airtel FPO',
    type: 'Mainboard',
    sector: 'Telecom',
    exchange: 'NSE / BSE',
    status: 'open',
    logoColor: '#dc2626',
    logoText: 'BA',
    priceBandLow: 1100,
    priceBandHigh: 1240,
    lotSize: 12,
    issueSize: 21000,
    issueSizeUnit: 'Cr',
    freshIssue: 21000,
    offerForSale: 0,
    openDate: '2026-10-02',
    closeDate: '2026-10-07',
    allotmentDate: '2026-10-09',
    refundDate: '2026-10-10',
    listingDate: '2026-10-12',
    description: 'Bharti Airtel is India\'s second-largest telecom operator with over 400 million subscribers. This FPO aims to raise capital for 5G network expansion, debt reduction, and spectrum payments.',
    leadManagers: ['Axis Capital', 'BofA Securities', 'SBI Capital Markets', 'Jefferies India'],
    registrar: 'Link Intime India',
    businessModel: 'Bharti Airtel earns revenue from mobile services (60%), enterprise solutions (15%), digital TV (10%), and Airtel Payments Bank (5%). ARPU has been steadily increasing with tariff hikes.',
    objectsOfIssue: [
      'Network expansion including 5G rollout across India',
      'Repayment of certain borrowings',
      'Spectrum payments to the government',
      'General corporate purposes',
    ],
    riskFactors: [
      'Intense competition from Reliance Jio',
      'Regulatory risks including AGR-related dues',
      'High capital expenditure requirements',
      'Foreign exchange risks from African operations',
    ],
    competitors: ['Reliance Jio', 'Vodafone Idea', 'BSNL'],
    promoters: [
      { name: 'Bharti Enterprises', preIssue: 53.2, postIssue: 48.8 },
      { name: 'Singtel', preIssue: 31.0, postIssue: 28.5 },
      { name: 'Public Shareholders', preIssue: 15.8, postIssue: 22.7 },
    ],
    lockInDetails: 'Promoter shares subject to 6-month lock-in per SEBI regulations.',
    financials: [
      { year: 'FY24', revenue: 150000, profit: 9500, ebitda: 75000, netWorth: 380000, debt: 120000, roe: 2.5, roce: 8.2, eps: 15.2 },
      { year: 'FY25', revenue: 165000, profit: 12000, ebitda: 82000, netWorth: 395000, debt: 110000, roe: 3.0, roce: 9.1, eps: 18.5 },
      { year: 'FY26', revenue: 180000, profit: 14500, ebitda: 90000, netWorth: 410000, debt: 95000, roe: 3.5, roce: 10.2, eps: 22.1 },
    ],
    reservation: { qib: 50, nii: 15, retail: 35 },
    peerComparison: [
      { name: 'Reliance Jio', pe: 22.5, marketCap: 950000 },
      { name: 'Bharti Airtel', pe: 38.2, marketCap: 750000 },
      { name: 'Vodafone Idea', pe: -15.3, marketCap: 45000 },
    ],
    subscription: { qib: 8.5, nii: 3.2, retail: 1.8, total: 4.2 },
    gmp: 45,
    gmpStatus: 'active',
    rhpLink: 'https://www.sebi.gov.in',
    drhpLink: 'https://www.nseindia.com',
    allotmentLink: 'https://www.linkintime.com',
  },
  {
    id: 'novcarbide-sme',
    name: 'Novelty Carbide',
    type: 'SME',
    sector: 'Manufacturing / Tungsten Products',
    exchange: 'NSE Emerge',
    status: 'upcoming',
    logoColor: '#78350f',
    logoText: 'NC',
    priceBandLow: 85,
    priceBandHigh: 90,
    lotSize: 1600,
    issueSize: 28,
    issueSizeUnit: 'Cr',
    freshIssue: 28,
    offerForSale: 0,
    openDate: '2026-10-15',
    closeDate: '2026-10-17',
    allotmentDate: '2026-10-20',
    refundDate: '2026-10-21',
    listingDate: '2026-10-23',
    description: 'Novelty Carbide manufactures tungsten carbide products including cutting tools, wear parts, and dies used in machining, mining, and oil drilling industries. Based in Ahmedabad, Gujarat.',
    leadManagers: ['Hem Securities'],
    registrar: 'Skyline Financial Services',
    businessModel: 'The company manufactures and sells tungsten carbide products to industrial clients. 70% revenue from cutting tools, 20% from wear parts, 10% from custom solutions.',
    objectsOfIssue: [
      'Setting up a new manufacturing facility for tungsten carbide products',
      'Purchase of new machinery and equipment',
      'Working capital requirements',
      'General corporate purposes',
    ],
    riskFactors: [
      'Dependence on imported raw materials (tungsten)',
      'Small scale of operations compared to large competitors',
      'Limited product diversification',
      'SME segment has lower liquidity post-listing',
    ],
    competitors: ['Sandvik Coromant', 'Kennametal India', 'Widia', 'Balaji Carbide'],
    promoters: [
      { name: 'Rajesh Patel', preIssue: 45.2, postIssue: 33.8 },
      { name: 'Sunita Patel', preIssue: 28.5, postIssue: 21.3 },
      { name: 'Public Shareholders', preIssue: 26.3, postIssue: 44.9 },
    ],
    lockInDetails: 'Promoter shares subject to 3-year lock-in for SME IPOs as per SEBI regulations (with 20% released each year).',
    financials: [
      { year: 'FY24', revenue: 42, profit: 4.2, ebitda: 8.5, netWorth: 22, debt: 12, roe: 19.1, roce: 22.5, eps: 2.1 },
      { year: 'FY25', revenue: 55, profit: 6.8, ebitda: 12.5, netWorth: 28, debt: 15, roe: 24.3, roce: 28.2, eps: 3.4 },
      { year: 'FY26', revenue: 68, profit: 9.1, ebitda: 16.2, netWorth: 35, debt: 14, roe: 26.0, roce: 30.5, eps: 4.6 },
    ],
    reservation: { qib: 50, nii: 15, retail: 35 },
    peerComparison: [
      { name: 'Kennametal India', pe: 42.5, marketCap: 3200 },
      { name: 'Sandvik Coromant', pe: 38.2, marketCap: 5800 },
      { name: 'Novelty Carbide', pe: 19.6, marketCap: 28 },
    ],
    subscription: { qib: 0, nii: 0, retail: 0, total: 0 },
    gmp: 0,
    gmpStatus: 'none',
    rhpLink: 'https://www.sebi.gov.in',
    drhpLink: 'https://www.nseindia.com',
    allotmentLink: 'https://www.skylinefinancial.com',
  },
  {
    id: 'greenpanel-plywood',
    name: 'Greenpanel Plywood',
    type: 'SME',
    sector: 'Manufacturing / Wood Products',
    exchange: 'BSE SME',
    status: 'closed',
    logoColor: '#16a34a',
    logoText: 'GP',
    priceBandLow: 65,
    priceBandHigh: 68,
    lotSize: 2000,
    issueSize: 18,
    issueSizeUnit: 'Cr',
    freshIssue: 18,
    offerForSale: 0,
    openDate: '2026-09-20',
    closeDate: '2026-09-24',
    allotmentDate: '2026-09-27',
    refundDate: '2026-09-28',
    listingDate: '2026-09-30',
    description: 'Greenpanel Plywood manufactures plywood, MDF boards, and decorative laminates for the furniture and construction industry. Based in Yamunanagar, Haryana with two manufacturing plants.',
    leadManagers: ['Vivro Financial Services'],
    registrar: 'Cameo Corporate Services',
    businessModel: 'The company manufactures and sells wood panels through a dealer network of 500+ dealers across India. 60% revenue from plywood, 25% from MDF, 15% from laminates.',
    objectsOfIssue: [
      'Capacity expansion of MDF manufacturing line',
      'Modernization of existing plywood facility',
      'Working capital for raw material procurement',
      'Listing benefits for brand visibility',
    ],
    riskFactors: [
      'Dependence on timber availability and prices',
      'Competition from unorganized sector',
      'Environmental regulations on wood processing',
      'SME segment liquidity concerns post-listing',
    ],
    competitors: ['Greenply Industries', 'Century Plyboards', 'National Plywood', 'Austin Plywood'],
    promoters: [
      { name: 'Saurabh Mittal', preIssue: 52.8, postIssue: 39.5 },
      { name: 'Priya Mittal', preIssue: 22.4, postIssue: 16.8 },
      { name: 'Public Shareholders', preIssue: 24.8, postIssue: 43.7 },
    ],
    lockInDetails: 'Promoter shares subject to 3-year lock-in for SME IPOs per SEBI regulations.',
    financials: [
      { year: 'FY24', revenue: 35, profit: 3.1, ebitda: 6.2, netWorth: 18, debt: 8, roe: 17.2, roce: 20.5, eps: 1.6 },
      { year: 'FY25', revenue: 42, profit: 4.5, ebitda: 8.1, netWorth: 22, debt: 7, roe: 20.5, roce: 24.1, eps: 2.3 },
      { year: 'FY26', revenue: 48, profit: 5.8, ebitda: 10.5, netWorth: 27, debt: 6, roe: 21.5, roce: 26.8, eps: 2.9 },
    ],
    reservation: { qib: 50, nii: 15, retail: 35 },
    peerComparison: [
      { name: 'Greenply Industries', pe: 25.4, marketCap: 1200 },
      { name: 'Century Plyboards', pe: 32.1, marketCap: 4800 },
      { name: 'Greenpanel Plywood', pe: 23.4, marketCap: 18 },
    ],
    subscription: { qib: 12.5, nii: 8.2, retail: 5.1, total: 7.8 },
    gmp: 8,
    gmpStatus: 'unverified',
    rhpLink: 'https://www.sebi.gov.in',
    drhpLink: 'https://www.bseindia.com',
    allotmentLink: 'https://www.cameocorporate.com',
  },
];

export const sectors = Array.from(new Set(ipos.map((ipo) => ipo.sector))).sort();
